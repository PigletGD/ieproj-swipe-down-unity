﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SocialPlatforms.GameCenter;

public class TowerBehaviour : MonoBehaviour
{
    private Transform target =  null;
    [SerializeField] SphereCollider collider;
    [SerializeField] GameObject bullet;
    [SerializeField] GameObject spawnpoint;
    private float time = 0.0f;
    private int firerate = 1;
    // Start is called before the first frame update

    private void OnTriggerEnter(Collider other)
    {
        if (target == null)
        {
            target = other.transform;
           
        }
    }
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        time += Time.deltaTime;
        if (target != null)
        {
            Vector3 direction = target.position - transform.position;
            transform.LookAt(direction);
            if(time >=  firerate){
                time -= 1.0f;
                GameObject temp = Instantiate(bullet, spawnpoint.transform.position, Quaternion.identity);
                temp.transform.LookAt(direction);
            }
        }
    }
}
