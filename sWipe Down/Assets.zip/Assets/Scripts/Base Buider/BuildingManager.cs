﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BuildingManager : MonoBehaviour
{
    static public BuildingManager instance = null;

    // Buildings
    [SerializeField] BuildingSO baseBuilding = null;
    [SerializeField] List<BuildingSO> buildingTypes = null;
    private Dictionary<string, GameObject> buildingDictionary = null;

    private BuildingSO currentBuilding = null;

    [SerializeField] GameManager gameManager = null;
    [SerializeField] MouseManager mouseManager = null;

    // Start is called before the first frame update
    void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);

            InitializeGame();
        }
    }

    public void InitializeGame()
    {
        buildingDictionary = new Dictionary<string, GameObject>();

        GameObject go = Instantiate(baseBuilding.buildingPrefab, new Vector3(0.5f, 0.0f, 0.5f), Quaternion.identity);
        buildingDictionary.Add("0 0", go);
    }

    public void InstantiateBuilding(Vector3 position)
    {
        int x = (int)(position.x - 0.5f);
        int y = (int)(position.z - 0.5f);

        string key = x.ToString() + " " + y.ToString();

        if (!buildingDictionary.ContainsKey(key))
        {
            GameObject go = Instantiate(currentBuilding.buildingPrefab, position, Quaternion.identity);
            buildingDictionary.Add(key, go);
            gameManager.SpendCurrency(currentBuilding.buildingCost);

            if (gameManager.Currency < currentBuilding.buildingCost) ChangeCurrentlySelectedBuilding(-1);
        }
    }

    public void ChangeCurrentlySelectedBuilding(int index)
    {
        if (index < 0 || index >= buildingTypes.Count)
        {
            if (mouseManager.objectFollow != null) Destroy(mouseManager.objectFollow);
            currentBuilding = null;
            mouseManager.objectFollow = null;
        }
        else
        {
            Destroy(mouseManager.objectFollow);
            currentBuilding = buildingTypes[index];
            mouseManager.objectFollow = Instantiate(currentBuilding.buildingPrefab);
        }
    }
}
